package Client;

import java.awt.*;
import javax.swing.*;


class BgPanel extends JPanel {
	Image bg=new ImageIcon("test.png").getImage();
	
	public void paintComponent(Graphics g) {
		g.drawImage(bg, 0, 0, 50, 50, this);
	}
}

class LoginPanel extends JPanel {
	LoginPanel(){
		setOpaque(false);
		setLayout(new FlowLayout());
		add(new Button("user name: ")); add(new JTextField(10));
		add(new Button("password: ")); add(new JPasswordField(10));
	}
}

class LogoutPanel extends JPanel {
	LogoutPanel(){
		setOpaque(false);
		setLayout(new GridLayout(2,2));
		add(new Button("��"),BorderLayout.NORTH);
		add(new Button("��"),BorderLayout.SOUTH);
		add(new Button("��"),BorderLayout.WEST);
		add(new Button("��"),BorderLayout.EAST);
	}
}


public class FrameTestBase extends JInternalFrame {
	public static void main(String[] args) {
		
		JPanel bgPanel =new BgPanel();
		bgPanel.setLayout(new BorderLayout());
		bgPanel.add(new LoginPanel(), BorderLayout.EAST);
		bgPanel.add(new LogoutPanel(), BorderLayout.WEST);
		
		FrameTestBase t=new FrameTestBase();
		t.setContentPane(bgPanel);
		t.setDefaultCloseOperation(EXIT_ON_CLOSE);
		t.setSize(1000,1000);
		t.setVisible(true);
		

	}

}
