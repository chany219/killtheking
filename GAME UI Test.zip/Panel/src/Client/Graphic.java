package Client;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.color.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;

import javax.swing.JButton;
import javax.swing.JFrame;


public class Graphic extends JPanel{
	
	ImageIcon icon= new ImageIcon("zzzzzz.png");
	   JLabel k=new JLabel();
	   
	   public Graphic(){
		      //this.setTitle("10�ȼ��� �̵�");
		      //this.setSize(200,200);
		     // this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		      this.setLayout(null);

		      //k.setIcon(icon);
		      //k.setLocation(50,50);
		      //k.setSize(40,40);
		      //k.setBounds(00, 400, 500, 500);
		      //this.add(k);
		      //this.setVisible(true);

	   }
	public void paint(Graphics g){

		g.fillRect(100, 100, 400, 400);
		for(int i=25;i<=100;i+=25){
			for(int j=25;j<=100;j+=25)
			{
				g.clearRect(i, j, 25, 25);
			}
		}

		for(int i=30;i<=120;i+=30)
		{
			for(int j=30;j<=120;j+=30)
			{
				g.clearRect(i, j, 50, 50);
			}
		}
	}
}